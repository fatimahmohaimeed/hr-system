﻿using HRSysremQassimTask.Entities;
using HRSysremQassimTask.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HRSysremQassimTask.Controllers
{
    [ApiController]
    [Route("api/employees")]
    public class EmployeesController : ControllerBase
    {
        private readonly HRSystemDbContext _context; 

        public EmployeesController(HRSystemDbContext context)
        {
            _context = context;
        }

        //[HttpGet]
        //public ActionResult<IEnumerable<Employee>> GetEmployees()
        //{
        //    return _context.Employees.ToList();
        //}

        //[HttpPost]
        //public ActionResult<Employee> AddEmployee([FromBody] Employee employee)
        //{
        //    // validation and error handling as needed
        //    _context.Employees.Add(employee);
        //    _context.SaveChanges();
        //    return employee;
        //}


        [HttpGet]
        [Route("GetEmployees")]
        public async Task<IEnumerable<Employee>> GetEmployees()
        {
            return await _context.Employees.ToListAsync();
        }

        [HttpPost]
        [Route("AddEmployee")]
        public async Task<NewEmployee> AddEmployee(NewEmployee objSEmployee)
        {
            Employee employee = new Employee()
            {
                Id = objSEmployee.Id,
                Name = objSEmployee.Name,
                Mobile = objSEmployee.Mobile,
                Email = objSEmployee.Email,
                DepartmentId = objSEmployee.DepartmentId,
            };
            
            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();
            return objSEmployee;
        }

        [HttpPatch]
        [Route("UpdateEmployee/{id}")]
        public async Task<Employee> UpdateEmployee(Employee objSEmployee)
        {
            _context.Entry(objSEmployee).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return objSEmployee;
        }

        [HttpDelete]
        [Route("DeleteEmployee/{id}")]
        public bool DeleteEmployee(int id)
        {
            bool a = false;
            var employee = _context.Employees.Find(id);
            if (employee != null)
            {
                a = true;
                _context.Entry(employee).State = EntityState.Deleted;
                _context.SaveChanges();
            }
            else
            {
                a = false;
            }
            return a;
        }
    }



}

