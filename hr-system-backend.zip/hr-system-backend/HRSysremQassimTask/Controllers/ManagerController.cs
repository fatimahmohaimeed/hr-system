﻿using HRSysremQassimTask.Entities;
using HRSysremQassimTask.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HRSysremQassimTask.Controllers
{
    [ApiController]
    [Route("api/managers")]
    public class ManagereController : ControllerBase
    {
        private readonly HRSystemDbContext _context;

        public ManagereController(HRSystemDbContext context)
        {
            _context = context;
        }


        [HttpGet]
        [Route("GetManageres")]
        public async Task<IEnumerable<Manager>> GetManageres()
        {
            return await _context.Managers.ToListAsync();
        }
        [HttpPost]
        [Route("AddDepartment")]
        public async Task<AddManager> AddManagere(AddManager objManager)
        {
            Manager manager = new Manager()
            {
                Id = objManager.Id,
                EmployeeManagerId = objManager.EmployeeManagerId,
                DepartmentManagerId = objManager.DepartmentManagerId,
            };
            _context.Managers.Add(manager);
            await _context.SaveChangesAsync();
            return objManager;
        }






    }
}