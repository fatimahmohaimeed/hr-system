﻿using HRSysremQassimTask.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HRSysremQassimTask.Controllers
{
    [ApiController]
    [Route("api/departments")]
    public class DepartmentsController : ControllerBase
    {
        private readonly HRSystemDbContext _context; 

        public DepartmentsController(HRSystemDbContext context)
        {
            _context = context;
        }

        //[HttpGet]
        //public ActionResult<IEnumerable<Department>> GetDepartments()
        //{
        //    return _context.Departments.Include(d => d.Employees).ToList();
        //}

        //[HttpPost]
        //public ActionResult<Department> AddDepartment([FromBody] Department department)
        //{
        //    // validation and error handling as needed
        //    _context.Departments.Add(department);
        //    _context.SaveChanges();
        //    return department;
        //}


        [HttpGet]
        [Route("GetDepartment")]
        public async Task<IEnumerable<Department>> GetDepartments()
        {
            return await _context.Departments.ToListAsync();
        }


        [HttpPost]
        [Route("AddDepartment")]
        public async Task<Department> AddDepartment(Department objDepartment)
        {
            _context.Departments.Add(objDepartment);
            await _context.SaveChangesAsync();
            return objDepartment;
        }


        [HttpPatch]
        [Route("UpdateDepartment/{id}")]
        public async Task<Department> UpdateDepartment(Department objDepartment)
        {
            _context.Entry(objDepartment).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return objDepartment;
        }


        [HttpDelete]
        [Route("DeleteDepartment/{id}")]
        public bool DeleteDepartment(int id)
        {
            bool a = false;
            var department = _context.Departments.Find(id);
            if (department != null)
            {
                a = true;
                _context.Entry(department).State = EntityState.Deleted;
                _context.SaveChanges();
            }
            else
            {
                a = false;
            }
            return a;
        }
    }



}

