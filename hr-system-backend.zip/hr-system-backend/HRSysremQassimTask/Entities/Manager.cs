﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HRSysremQassimTask.Entities
{
    public class Manager
    {
        [Key]
        public int Id { get; set; }




        [ForeignKey("EmployeeManagerId")]
        public int? EmployeeManagerId { get; set; }
        public Employee? EmployeeManager { get; set; }

        [ForeignKey("DepartmentManagerId")]
        public int? DepartmentManagerId { get; set; }
        public Department? DepartmentManager { get; set; }

    }
}
