﻿using Microsoft.EntityFrameworkCore;

namespace HRSysremQassimTask.Entities
{
    public class HRSystemDbContext : DbContext
    {
        //private static readonly EFLoggerForTesting _interceptor;


        public HRSystemDbContext(DbContextOptions<HRSystemDbContext> options) : base(options)
        {
        }
        public DbSet<Manager> Managers { get; set; }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=HRSystemQassim;Integrated Security=True");
        }
        //builder.Services.AddControllers().AddNewtonsoftJson(options =>
        //    {
        //    options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
        //    options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
        //});
    }
}
