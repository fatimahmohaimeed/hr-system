﻿using HRSysremQassimTask.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace HRSysremQassimTask.Models
{
    public class AddManager
    {
        public int Id { get; set; }
        public int? EmployeeManagerId { get; set; }
        public int? DepartmentManagerId { get; set; }

    }
}
